﻿/* 
 * Programa principal. 
 * Menú interactivo de la agenda de contactos.
 */
using System;

class Program
{
    enum opciones {NUEVO = 1, BORRAR, BUSCAR_CIUDAD, BUSCAR_ANYO, ORDENAR, 
                    SALIR}

    static opciones MostrarMenu()
    {
        opciones opcion;

        Console.WriteLine("\n== MENÚ ==");
        Console.WriteLine("1. Añadir contacto");
        Console.WriteLine("2. Borrar contacto");
        Console.WriteLine("3. Mostrar contactos de una ciudad");
        Console.WriteLine("4. Mostrar contactos por año");
        Console.WriteLine("5. Ordenar contactos por nombre");
        Console.WriteLine("6. Salir del programa");
        Console.Write("\nElige una opción: ");
        opcion = (opciones)Convert.ToInt32(Console.ReadLine());

        return opcion;
    }

    static void Main()
    {
        GestionContactos agenda = new GestionContactos();
        opciones opcion;
        int anyoBuscado;
        string ciudadBuscada;

        do
        {
            opcion = MostrarMenu();

            switch (opcion)
            {
                case opciones.NUEVO:
                    agenda.NuevoContacto();
                    break;

                case opciones.BORRAR:
                    agenda.BorrarContacto();
                    break;

                case opciones.BUSCAR_CIUDAD:
                    Console.Write("Introduce el nombre de la ciudad: ");
                    ciudadBuscada = Console.ReadLine();
                    agenda.MostrarContactosCiudad(ciudadBuscada);
                    break;

                case opciones.BUSCAR_ANYO:
                    Console.Write("Introduce el año de nacimiento: ");
                    anyoBuscado = Convert.ToInt32(Console.ReadLine());
                    agenda.MostrarContactosAnyo(anyoBuscado);
                    break;

                case opciones.ORDENAR:
                    agenda.OrdenarContactos();
                    break;

                case opciones.SALIR:
                    Console.WriteLine("Saliendo del programa...");
                    break;

                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }

        } while (opcion != opciones.SALIR);
    }
}
