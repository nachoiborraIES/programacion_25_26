﻿/*
 * Gestiona la agenda de contactos.
 */
using System;
using System.Collections.Generic;

class GestionContactos
{
    private List<Contacto> contactos;

    public GestionContactos()
    {
        contactos = new List<Contacto>();
    }

    public void NuevoContacto()
    {
        string nombre, direccion, telefono, ciudad;
        bool fechaValida;
        int dia = 0, mes = 0, anyo = 0;

        do
        {
            Console.Write("Nombre y apellidos: ");
            nombre = Console.ReadLine();
        } while (nombre == "");

        do
        {
            Console.Write("Dirección: ");
            direccion = Console.ReadLine();
        } while (direccion == "");

        do
        {
            Console.Write("Teléfono: ");
            telefono = Console.ReadLine();
        } while (telefono == "");

        do
        {
            Console.Write("Ciudad: ");
            ciudad = Console.ReadLine();
        } while (ciudad == "");

        do
        {
            Console.Write("Fecha de nacimiento (dd/mm/aaaa): ");
            string fechaTexto = Console.ReadLine();
            string[] partes = fechaTexto.Split('/');

            fechaValida = false;

            if (partes.Length == 3
                && Int32.TryParse(partes[0], out dia)
                && Int32.TryParse(partes[1], out mes)
                && Int32.TryParse(partes[2], out anyo))
            {
                if (dia >= 1 && dia <= 31 &&
                    mes >= 1 && mes <= 12 &&
                    anyo >= 1950 && anyo <= 2020)
                {
                    fechaValida = true;
                }
                else
                {
                    Console.WriteLine("Fecha no válida");
                }
            }
            else
            {
                Console.WriteLine("Formato incorrecto");
            }

        } while (!fechaValida);

        Contacto nuevo = new Contacto(nombre, direccion, telefono, ciudad, 
            dia, mes, anyo);
        contactos.Add(nuevo);
        Console.WriteLine("Contacto añadido correctamente.");
    }

    public void BorrarContacto()
    {
        int posicion;
        if (contactos.Count > 0)
        {
            Console.WriteLine("\n== CONTACTOS ACTUALES ==");
            for (int i = 0; i < contactos.Count; i++)
            {
                Console.WriteLine(contactos[i]);
            }

            do
            {
                Console.Write("¿Qué contacto quieres borrar? ");
                posicion = Convert.ToInt32(Console.ReadLine());
            } while (posicion < 1 || posicion > contactos.Count);

            contactos.RemoveAt(posicion - 1);
            Console.WriteLine("Contacto borrado correctamente.");
        }
        else
        {
            Console.WriteLine("No hay contactos para borrar.");
        }
    }

    public void MostrarContactosCiudad(string ciudadBuscada)
    {
        bool encontrado = false;

        if (contactos.Count > 0)
        {
            foreach (Contacto c in contactos)
            {
                if (c.Ciudad.ToLower() == ciudadBuscada.ToLower())
                {
                    Console.WriteLine(c);
                    encontrado = true;
                }
            }

            if (!encontrado)
            {
                Console.WriteLine("No existen contactos de esa ciudad");
            }
        }
        else
        {
            Console.WriteLine("No hay contactos almacenados.");
        }
    }

    public void MostrarContactosAnyo(int anyoBuscado)
    {
        bool encontrado = false;

        foreach (Contacto c in contactos)
        {
            if (c.AnyoNacimiento == anyoBuscado)
            {
                Console.WriteLine(c);
                encontrado = true;
            }
        }

        if (!encontrado)
        {
            Console.WriteLine("No se encontraron contactos de ese año");
        }
    }

    public void OrdenarContactos()
    {
        if (contactos.Count > 0)
        {
            contactos.Sort();

            Console.WriteLine("\n== CONTACTOS ORDENADOS POR NOMBRE ==");
            foreach (Contacto c in contactos)
            {
                Console.WriteLine(c);
            }
        }
        else
        {
            Console.WriteLine("No hay contactos almacenados.");
        }
    }
}
