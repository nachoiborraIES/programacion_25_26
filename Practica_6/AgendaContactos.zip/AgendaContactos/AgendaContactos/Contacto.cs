﻿/*
 * Almacena la información de cada contacto en la agenda.
 */
using System;

class Contacto : IComparable<Contacto>
{
    private string nombreApellidos;
    private string direccion;
    private string telefono;
    private string ciudad;
    private int diaNacimiento;
    private int mesNacimiento;
    private int anyoNacimiento;

    public Contacto(string nombreApellidos, string direccion, string telefono,
                    string ciudad, int diaNacimiento, int mesNacimiento,
                    int anyoNacimiento)
    {
        this.nombreApellidos = nombreApellidos;
        this.direccion = direccion;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.diaNacimiento = diaNacimiento;
        this.mesNacimiento = mesNacimiento;
        this.anyoNacimiento = anyoNacimiento;
    }

    public string NombreApellidos
    {
        get { return nombreApellidos; }
        set { nombreApellidos = value; }
    }

    public string Direccion
    {
        get { return direccion; }
        set { direccion = value; }
    }

    public string Telefono
    {
        get { return telefono; }
        set { telefono = value; }
    }

    public string Ciudad
    {
        get { return ciudad; }
        set { ciudad = value; }
    }

    public int DiaNacimiento
    {
        get { return diaNacimiento; }
        set { diaNacimiento = value; }
    }

    public int MesNacimiento
    {
        get { return mesNacimiento; }
        set { mesNacimiento = value; }
    }

    public int AnyoNacimiento
    {
        get { return anyoNacimiento; }
        set { anyoNacimiento = value; }
    }

    public override string ToString()
    {
        return nombreApellidos + ", " + direccion + ", " + telefono + ", " 
           + ciudad + ", " + diaNacimiento.ToString("00") + "/" 
           + mesNacimiento.ToString("00") + "/" + anyoNacimiento;
    }

    public int CompareTo(Contacto otro)
    {
        return this.nombreApellidos.CompareTo(otro.nombreApellidos);
    }
}
