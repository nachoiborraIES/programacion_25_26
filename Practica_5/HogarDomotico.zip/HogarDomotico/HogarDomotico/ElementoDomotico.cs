﻿/*
 * Clase padre de cualquier elemento domótico del sistema
 */
abstract class ElementoDomotico
{
    protected string nombre;

    public string Nombre
    {
        get { return nombre; }
        set { nombre = value; }
    }

    public ElementoDomotico(string nombre)
    {
        this.nombre = nombre;
    }

    public abstract void Mostrar();
}