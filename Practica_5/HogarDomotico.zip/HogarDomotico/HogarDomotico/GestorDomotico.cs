﻿/*
 * Clase que gestiona un conjunto de componentes domóticos del hogar
 */
class GestorDomotico
{
    private ElementoDomotico[] elementos;

    public GestorDomotico()
    {
        elementos = new ElementoDomotico[6];
        elementos[0] = new Puerta("Puerta principal");
        elementos[1] = new Puerta("Puerta garaje");
        elementos[2] = new Luz("Luz salón");
        elementos[3] = new Luz("Luz cocina");
        elementos[4] = new Horno("Horno cocina");
        elementos[5] = new Calefaccion("Calefaccion salón");
    }

    public ElementoDomotico GetElemento(int posicion)
    {
        return elementos[posicion];
    }

    public void MostrarEstado()
    {
        int fila = 1, columna = 3;
        for (int i = 0; i < elementos.Length; i++)
        {
            Console.SetCursorPosition(columna, fila + i);
            elementos[i].Mostrar();
        }
    }

    public void ApagarTodo()
    {
        foreach(ElementoDomotico e in elementos)
        {
            if (e is IEncendible)
            {
                ((IEncendible)e).Apagar();
            }
        }
    }
}