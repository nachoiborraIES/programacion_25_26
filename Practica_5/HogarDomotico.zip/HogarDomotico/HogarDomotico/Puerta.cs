﻿/*
 * Clase para elementos domóticos de tipo puerta
 */
class Puerta : ElementoDomotico
{
    private bool abierta;

    public Puerta(string nombre): base(nombre)
    {
        this.abierta = false;
    }

    public void Abrir()
    {
        this.abierta = true;
    }

    public void Cerrar()
    {
        this.abierta = false;
    }

    public bool Consultar()
    {
        return this.abierta;
    }

    public override void Mostrar()
    {
        if (abierta)
        {
            Console.BackgroundColor = ConsoleColor.Green;
        }
        else
        {
            Console.BackgroundColor = ConsoleColor.Red;
        }
        Console.Write(" ");
        Console.ResetColor();
        Console.Write(" " + nombre);
    }
}