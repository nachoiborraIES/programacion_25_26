﻿/*
 * Elemento domótico de tipo calefaccion
 */
class Calefaccion : ElementoTemperatura
{
    public int Temperatura
    {
        get { return temperatura; }

        set
        {
            if (value >= 15 && value <= 30)
            {
                temperatura = value;
            }
        }
    }
    public Calefaccion(string nombre) : base(nombre)
    {
        this.temperatura = 15;
    }
}