//Ventana principal donde se realizan las interacciones del programa.

namespace BibliotecaMusica
{
    public partial class Biblioteca : Form
    {
        private List<Cancion> canciones;
        private List<Autor> autores;

        public Biblioteca()
        {
            InitializeComponent();

            autores = Autor.CargarAutores();
            canciones = Cancion.CargarCanciones();
            MostrarCanciones(canciones);

            foreach (Autor a in autores)
            {
                cmbAutor.Items.Add(a);
                cmbFiltradoAutor.Items.Add(a);
            }
        }

        private void MostrarCanciones(List<Cancion> canciones)
        {
            listCanciones.Items.Clear();

            foreach (Cancion c in canciones)
            {
                listCanciones.Items.Add(c.ToString());
            }
        }

        private void btnAnyadir_Click(object sender, EventArgs e)
        {
            Autor autor = (Autor)(cmbAutor.SelectedItem);

            if (txtTitulo.Text != "" && txtMinutos.Text != "" &&
                txtSegundos.Text != "" && autor != null)
            {
                string titulo = txtTitulo.Text;
                int minutos = Convert.ToInt32(txtMinutos.Text);
                int segundos = Convert.ToInt32(txtSegundos.Text);

                Cancion nuevaCancion =
                    new Cancion(titulo, minutos, segundos, autor);
                canciones.Add(nuevaCancion);
                MostrarCanciones(canciones);
            }
            else
            {
                MessageBox.Show("Los campos no pueden estar vacíos");
            }
        }

        private void btnAplicarFiltros_Click(object sender, EventArgs e)
        {
            Autor autorFiltrado = (Autor)cmbFiltradoAutor.SelectedItem;
            List<Cancion> filtradas = new List<Cancion>();

            if (autorFiltrado != null && 
                txtFiltradoMinutos.Text != "")
            {
                int minutosFiltrados = Convert.ToInt32(txtFiltradoMinutos.Text);
            
                foreach (Cancion c in canciones)
                {
                    if (c.Autor.Equals(autorFiltrado) &&
                        c.Minutos < minutosFiltrados)
                    {
                        filtradas.Add(c);
                    }
                }
            }

            else if (txtFiltradoMinutos.Text != "")
            {
                int minutosFiltrados = Convert.ToInt32(txtFiltradoMinutos.Text);
     
                foreach (Cancion c in canciones)
                {
                    if (c.Minutos < minutosFiltrados)
                    {
                        filtradas.Add(c);
                    }
                }
            }

            else if (autorFiltrado != null)
            {
                foreach (Cancion c in canciones)
                {
                    if (c.Autor.Equals(autorFiltrado))
                    {
                        filtradas.Add(c);
                    }
                }
            }

            else
            {
                filtradas = canciones;
            }

            MostrarCanciones(filtradas);
        }

        private void btnBorrarFiltros_Click(object sender, EventArgs e)
        {
            txtFiltradoMinutos.Text = "";
            cmbFiltradoAutor.SelectedIndex = -1;

            MostrarCanciones(canciones);
        }

        private void Biblioteca_FormClosing(object sender,
                                            FormClosingEventArgs e)
        {
            Cancion.GuardarCanciones(canciones);
        }
    }
}
