﻿//Clase Canción con las características de las canciones serializadas.

using System.Text.Json;

namespace BibliotecaMusica
{
    internal class Cancion
    {
        const string FICHEROCANCIONES = "canciones.json";

        protected string titulo;
        protected int minutos;
        protected int segundos;
        protected Autor autor;

        public Cancion(string titulo, int minutos, int segundos, Autor autor)
        {
            this.titulo = titulo;
            this.Minutos = minutos;
            this.Segundos = segundos;
            this.autor = autor;
        }

        public string Titulo
        {
            get { return titulo; }
            set { titulo = value; }
        }

        public int Minutos
        {
            get { return minutos; }
            set
            {
                minutos = value >= 0 ? value : 0;
            }
        }

        public int Segundos
        {
            get { return segundos; }
            set 
            {
                if (value < 0)
                {
                    segundos = 0;
                }
                else if (value > 59)
                {
                    segundos = 59;
                }
                else
                {
                    segundos = value;
                }
            }
        }

        public Autor Autor
        {
            get { return autor;}
            set {  autor = value;}
        }

        public static List<Cancion> CargarCanciones()
        {
            List<Cancion> listado = new List<Cancion>();
            if (File.Exists(FICHEROCANCIONES))
            {
                string jsonString = File.ReadAllText(FICHEROCANCIONES);
                listado = JsonSerializer.Deserialize<List<Cancion>>(jsonString);
            }

            return listado;
        }

        public static void GuardarCanciones(List<Cancion> canciones)
        {
            var opciones = new JsonSerializerOptions { WriteIndented = true };
            string jsonString2 = JsonSerializer.Serialize(canciones, opciones);
            File.WriteAllText(FICHEROCANCIONES, jsonString2);
        }

        public override string ToString()
        {
            return "[" + autor + "] " + titulo + " (" + minutos + ":" +
                segundos + ")";
        }
    }
}
