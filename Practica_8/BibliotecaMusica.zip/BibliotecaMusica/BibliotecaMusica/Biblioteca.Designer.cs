﻿namespace BibliotecaMusica
{
    partial class Biblioteca
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtTitulo = new TextBox();
            lblTitulo = new Label();
            lblMinutos = new Label();
            txtMinutos = new TextBox();
            label4 = new Label();
            txtSegundos = new TextBox();
            label5 = new Label();
            cmbAutor = new ComboBox();
            btnAnyadir = new Button();
            groupFiltrado = new GroupBox();
            btnBorrarFiltros = new Button();
            btnAplicarFiltros = new Button();
            txtFiltradoMinutos = new TextBox();
            label7 = new Label();
            label6 = new Label();
            cmbFiltradoAutor = new ComboBox();
            listCanciones = new ListBox();
            groupFiltrado.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(508, 31);
            label1.Name = "label1";
            label1.Size = new Size(128, 20);
            label1.TabIndex = 1;
            label1.Text = "Nuevas Canciones";
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(408, 67);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(359, 27);
            txtTitulo.TabIndex = 2;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(334, 74);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(50, 20);
            lblTitulo.TabIndex = 3;
            lblTitulo.Text = "Título:";
            // 
            // lblMinutos
            // 
            lblMinutos.AutoSize = true;
            lblMinutos.Location = new Point(334, 121);
            lblMinutos.Name = "lblMinutos";
            lblMinutos.Size = new Size(65, 20);
            lblMinutos.TabIndex = 4;
            lblMinutos.Text = "Minutos:";
            // 
            // txtMinutos
            // 
            txtMinutos.Location = new Point(408, 114);
            txtMinutos.Name = "txtMinutos";
            txtMinutos.Size = new Size(125, 27);
            txtMinutos.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(559, 117);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 6;
            label4.Text = "Segundos:";
            // 
            // txtSegundos
            // 
            txtSegundos.Location = new Point(642, 114);
            txtSegundos.Name = "txtSegundos";
            txtSegundos.Size = new Size(125, 27);
            txtSegundos.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(334, 163);
            label5.Name = "label5";
            label5.Size = new Size(49, 20);
            label5.TabIndex = 8;
            label5.Text = "Autor:";
            // 
            // cmbAutor
            // 
            cmbAutor.FormattingEnabled = true;
            cmbAutor.Location = new Point(409, 155);
            cmbAutor.Name = "cmbAutor";
            cmbAutor.Size = new Size(359, 28);
            cmbAutor.TabIndex = 9;
            // 
            // btnAnyadir
            // 
            btnAnyadir.BackColor = SystemColors.ButtonFace;
            btnAnyadir.Location = new Point(518, 202);
            btnAnyadir.Name = "btnAnyadir";
            btnAnyadir.Size = new Size(153, 29);
            btnAnyadir.TabIndex = 10;
            btnAnyadir.Text = "Añadir";
            btnAnyadir.UseVisualStyleBackColor = false;
            btnAnyadir.Click += btnAnyadir_Click;
            // 
            // groupFiltrado
            // 
            groupFiltrado.Controls.Add(btnBorrarFiltros);
            groupFiltrado.Controls.Add(btnAplicarFiltros);
            groupFiltrado.Controls.Add(txtFiltradoMinutos);
            groupFiltrado.Controls.Add(label7);
            groupFiltrado.Controls.Add(label6);
            groupFiltrado.Controls.Add(cmbFiltradoAutor);
            groupFiltrado.Location = new Point(327, 253);
            groupFiltrado.Name = "groupFiltrado";
            groupFiltrado.Size = new Size(461, 155);
            groupFiltrado.TabIndex = 11;
            groupFiltrado.TabStop = false;
            groupFiltrado.Text = "Filtrado de canciones";
            // 
            // btnBorrarFiltros
            // 
            btnBorrarFiltros.BackColor = SystemColors.ButtonFace;
            btnBorrarFiltros.Location = new Point(260, 120);
            btnBorrarFiltros.Name = "btnBorrarFiltros";
            btnBorrarFiltros.Size = new Size(162, 29);
            btnBorrarFiltros.TabIndex = 5;
            btnBorrarFiltros.Text = "Borrar Filtros";
            btnBorrarFiltros.UseVisualStyleBackColor = false;
            btnBorrarFiltros.Click += btnBorrarFiltros_Click;
            // 
            // btnAplicarFiltros
            // 
            btnAplicarFiltros.BackColor = SystemColors.ButtonFace;
            btnAplicarFiltros.Location = new Point(40, 120);
            btnAplicarFiltros.Name = "btnAplicarFiltros";
            btnAplicarFiltros.Size = new Size(162, 29);
            btnAplicarFiltros.TabIndex = 4;
            btnAplicarFiltros.Text = "Aplicar Filtros";
            btnAplicarFiltros.UseVisualStyleBackColor = false;
            btnAplicarFiltros.Click += btnAplicarFiltros_Click;
            // 
            // txtFiltradoMinutos
            // 
            txtFiltradoMinutos.Location = new Point(212, 38);
            txtFiltradoMinutos.Name = "txtFiltradoMinutos";
            txtFiltradoMinutos.Size = new Size(232, 27);
            txtFiltradoMinutos.TabIndex = 3;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 79);
            label7.Name = "label7";
            label7.Size = new Size(49, 20);
            label7.TabIndex = 2;
            label7.Text = "Autor:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 41);
            label6.Name = "label6";
            label6.Size = new Size(196, 20);
            label6.TabIndex = 1;
            label6.Text = "Duración máxima (minutos):";
            // 
            // cmbFiltradoAutor
            // 
            cmbFiltradoAutor.FormattingEnabled = true;
            cmbFiltradoAutor.Location = new Point(86, 79);
            cmbFiltradoAutor.Name = "cmbFiltradoAutor";
            cmbFiltradoAutor.Size = new Size(358, 28);
            cmbFiltradoAutor.TabIndex = 0;
            // 
            // listCanciones
            // 
            listCanciones.Dock = DockStyle.Left;
            listCanciones.FormattingEnabled = true;
            listCanciones.Location = new Point(0, 0);
            listCanciones.Name = "listCanciones";
            listCanciones.Size = new Size(299, 450);
            listCanciones.TabIndex = 12;
            // 
            // Biblioteca
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listCanciones);
            Controls.Add(groupFiltrado);
            Controls.Add(btnAnyadir);
            Controls.Add(cmbAutor);
            Controls.Add(label5);
            Controls.Add(txtSegundos);
            Controls.Add(label4);
            Controls.Add(txtMinutos);
            Controls.Add(lblMinutos);
            Controls.Add(lblTitulo);
            Controls.Add(txtTitulo);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Biblioteca";
            Text = "Biblioteca Musical";
            FormClosing += Biblioteca_FormClosing;
            groupFiltrado.ResumeLayout(false);
            groupFiltrado.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox txtTitulo;
        private Label lblTitulo;
        private Label lblMinutos;
        private TextBox txtMinutos;
        private Label label4;
        private TextBox txtSegundos;
        private Label label5;
        private ComboBox cmbAutor;
        private Button btnAnyadir;
        private GroupBox groupFiltrado;
        private Button btnBorrarFiltros;
        private Button btnAplicarFiltros;
        private TextBox txtFiltradoMinutos;
        private Label label7;
        private Label label6;
        private ComboBox cmbFiltradoAutor;
        private ListBox listCanciones;
    }
}
