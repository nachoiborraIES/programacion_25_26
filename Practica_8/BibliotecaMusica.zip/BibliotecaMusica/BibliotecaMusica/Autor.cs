﻿//Clase Autor con el nombre y booleano indicando si es un grupo o no.

namespace BibliotecaMusica
{
    internal class Autor
    {
        const string FICHERO = "autores.txt";

        protected string nombre;
        protected bool grupo;

        public Autor(string nombre, bool grupo)
        {
            this.nombre = nombre;
            this.grupo = grupo;
        }

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        public bool Grupo
        {
            get { return grupo; }
            set { grupo = value; }
        }

        public static List<Autor> CargarAutores()
        {
            List<Autor> autores = new List<Autor>();
            string linea;

            if (File.Exists(FICHERO))
            {
                using (StreamReader fichero = new StreamReader(FICHERO))
                {
                    while ((linea = fichero.ReadLine()) != null)
                    {
                        string[] partes = linea.Split(';');

                        if (partes.Length == 2)
                        {
                            string nombre1 = partes[0];
                            bool esGrupo = false;

                            if (Convert.ToInt32(partes[1]) == 1)
                            {
                                esGrupo = true;
                            }

                            autores.Add(new Autor(nombre1, esGrupo));
                        }
                    }
                }
            }
            return autores;
        }

        public override bool Equals(object? obj)
        {
            return obj is Autor autor &&
                   nombre == autor.nombre;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(nombre);
        }

        public override string ToString()
        {
            return nombre;
        }
    }
}
